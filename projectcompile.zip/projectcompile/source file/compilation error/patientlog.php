<!DOCTYPE html>

<html>


<head>
	<title>compilation error</title> 
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<style>
		*{
			margin:0;
			padding: 0;

		}
		body{
			background-repeat: no-repeat, repeat;
			background-size: cover;
		   
		}
		.online{
			
			height: 10%;
			width:100%;
			background-color:#c2dfff;
			border:2px solid skyblue;
			color:blue;
			margin-left:0px;
		}
		.on{
			margin-left: 35%;
		}
		.group{
			float:left;
			color:white;
			margin-left: 20%;

		}
		.log{
			float:right;
			color:white;
			margin-right: 20%;
		}
		
		.bx5{
			float:center;
			height:450px;
			width:500px;
			background:skyblue;
			border:2px solid #c2dfff;
			margin-top: 38%;
            margin-left: 33%;
            border-radius: 100px;
            position: absolute;
            transform: translate(-2%,-98%);

		}
		.icon{
			margin-top: 2%;
			

		}
		input{
			margin-left: 20%;
			height:30px;
			width:60%;
			margin-top: 5%;

		}
				.btn{
			width: 40%;
			background:blue;
			border:2px solid skyblue;
			color:white;
			padding: 5px;
			font-size: 18px;
			cursor: pointer;
			margin: 16px 0;
			margin-left: 30%;
			margin-top: 5%;
			height:40px;
			border-radius: 15px;

		}
	.reg{
			margin-top: 2%;
			margin-left: 15%;
			padding: 10px;
			font-size: 30px;
			color: black;
			
		}
		.res{
			margin-top: 2%;
			margin-left:0%;
			padding: 10px;
			font-size: 30px;
			color: green;
			text-decoration: none;
			
		}
			.profile{
				height:100px;
				width: 100px;
				border-radius:50px;
			}
			.input{
				border-radius: none;

			}
	
		
	</style>
</head>
<body background="Medical2.jpg">
	
	
	
	<div class="online">
		

		<h1 class="on"> REAL TIME MEDICATION</h1>
		
	</div><br>
		<div class="bx5">
			<form method="post"><div class="icon"><h2><center><img src="pro.png" class="profile"></center></h2></div>
			<input type="text" name="email" placeholder="email id" maxlength="50" class="input">
			<input type="password" name="pass" placeholder="password" class="input"><br>
			
				<input type="submit" name="login" value="login" class="btn">
				<div class="reg">Not registered?<a href="registration.php" class="res">Registered here</a></div>
			</form></div>
	</div>
	<div>
	

			
			
	</div>		

</body>
</html>
<?php 
      $abc=mysqli_connect('localhost','root','');
      mysqli_select_db($abc,'realtime') or die('plz check database');

if(isset($_POST['login']))
{
	$uname=$_POST['email'];
	$pass=$_POST['pass'];


	
	$query=mysqli_query($abc,"select *from patientreg where email='$uname' and password='$pass'");
	$ins=mysqli_fetch_array($query);
	
	if($ins>0)
	{
		//$_SESSION['rollno']=$rollno;
		//$_SESSION['password']=$pass;
		
	   echo "<script> location.href='hospitalnames.html'</script>";
		

}
else{
	
	echo "<script> alert('password did not match with username.')</script>";

}
}
     ?>     

