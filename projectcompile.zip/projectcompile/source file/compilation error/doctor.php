<!DOCTYPE html>
<html>
<head>
	
	<title>real time medication</title>
	<style >
		*{
			margin:0px;
			padding: 0px;

		}
		body{
			
			background-color:#addfff;
            background-image:url("medical4.jpg");
            background-size: cover;
		}
	
		.online{
			
			height: 10%;
			width:100%;
			background-color: skyblue;
			border:1px solid #cddfff;
			color:white;
			margin-left:0px;
			position: absolute;
		}
		.on{
			margin-left: 35%;
			margin-top: 1%;
		}
		.logout{
			float:right;
			margin-left: 5%;
	        margin-top: -2.5%;
	        margin-right: 10%;
	         
	        text-underline-position:none;
	        background-color: blue;
	        border:2px solid #cddfff;
	        height:30px;
	        width:100px;
	        border-radius: 15px;
	        color:white;

		}
		.bx1{
			
			height:60%;
			width:60%;
			background:skyblue;
			margin-top: 10%;
			left: 18%;
		    border:2px solid skyblue ;
            border-radius: 20px;
            position: absolute;
            padding: 30px;
            font-size: 20px;
            color:blue;

        
		}
		
		.bx{
			
			height:80px;
			width:94%;
			background: #950740;
			border:2px solid #e75874 ;
			margin-top: 1%;
            margin-left:1% ;
            border-radius: 5px;
            font-size:20px;
            color:white;
            padding-left: 20px;

        

		}
		.btn{
			margin-top: 5%;
			margin-left:35%;
			
			font-size: 20px;
			
		}
		.bt{
			width:12%;
			background:#78244c;
			border:3px solid #e75874;
			color:white;
			border-radius: 15px;
			
			cursor: pointer;
			margin-left: 20%;
			margin-bottom: 15%;
			
		
			
			height:30px;}
			



</style>
</head>
<body>

	
	<div class="online" >
		<h1 class="on"> <i>REAL TIME MEDICATION</i></h1>
         <a href="firstpage.html" ><input type="submit" name="logout" value="logout" class="logout"></a>
   
         
             
         	
     
         	</h1>
     </div>
     <br>
          
     <div class="bx1">
    
     	<?php SESSION_start();
     	
     	 $abc=mysqli_connect('localhost','root','');
                mysqli_select_db($abc,'realtime') or die('plz check database');

     	$mobileno=$_SESSION['mobileno'];
        
     	$query="select * from doctorreg where mobileno='$mobileno'";
     	$info=mysqli_query($abc,$query);
     	$result=mysqli_fetch_array($info);
     	
     	 
     	echo "<br>";
     
        echo  "Name :"."&nbsp".$result['name']."<br>"."<br>";
     	echo "Address :"."&nbsp".$result['address']."<br>"."<br>";
     	echo "City :"."&nbsp".$result['city']."<br>"."<br>";
     	echo "State :"."&nbsp".$result['state']."<br>"."<br>";
     	echo "mobileno :"."&nbsp".$result['mobileno']."<br>"."<br>";
     	echo "department :"."&nbsp". $result['Department']."<br>"."<br>";
        echo "Hospital :"."&nbsp". $result['hospital']."<br>"."<br>";
        echo "Email_id :"."&nbsp". $result['email']."<br>"."<br>";
     	
             
     ?>

     	
     </div>
      </body>
      </html>

      