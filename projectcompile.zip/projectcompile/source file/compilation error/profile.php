<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EMERGENCY</title>
    <style type="text/css">
        * {
            margin: 0;
            padding: 0;
        }
        
         form {
            width: 800px;
            background-color: rgb(0, 0, 0, 6) transparent;
            margin-top:5%;
            margin-left:20%;
            color: black;
            padding: 10px ;
           
            border-radius: 15px ;
          

        }
       
        button {
            width: 40%;
			background-color:white;
			border:5px solid skyblue;
			color:blue;
		
			font-size: 18px;
			cursor: pointer;
			margin: 16px 0;
			margin-left: 0%;
			margin-top: 5%;
			height:40px;
			border-radius: 15px;
 }
        

        body {
            background-image:url(g.jpg);
            background-position: center;
            background-size:cover;
            font-family: sans-serif;
            margin-top: 5%;
            margin-left:25%;
            border:5px solid white;
            border-radius:20px;
            width: 50%;
            height:70%;
}
  
        .button:hover {
            background-color:white;
        }


    </style>
</head>
<body>
        <form>
  <h2 class="person"><font color="black"><i>I am available.</i></font></h2>
           <input type="radio" name="agree" value="yes" class="radio">YES<br>
           <input type="radio" name="agree" value="no" class="radio">NO<br>
           
            <button type="submit" required="required" name="submit"><a href="thankyou.html">Submit</a></button>
            </label>
            </form>
        </body>
        </html>