</!DOCTYPE html>
<html>
<head>
	<title></title>
	<style >
		body{
			background-image:url("medical1.jpg");
			background-size: cover;
		}
		.online{
			
			height: 10%;
			width:100%;
			background-color: #c2dfff;
			border:2px solid skyblue;
			color:blue;
			margin-left:0px;
		}
		
		.on{
			margin-left: 35%;
		}
		.bx{
			
			height:400px;
			width:480px;
			background:skyblue;
			border:2px solid #c2dfff;
			top:50%;
			left:50%;
			margin-top:3%; 
            border-radius: 20px;
            position: absolute;
            transform: translate(-50%,-50%);

		}
		.profile{
				height:130px;
				width: 130px;
				border-radius:70px;
			}
			input{
			margin-left: 20%;
			height:30px;
			width:60%;
			margin-top: 5%;

		}
		.vote{
			margin-left: 20%;
			height:30px;
			width:60%;
			margin-top: 5%;
			border-radius: none;
			
		}
		.btn{
			width: 40%;
			background:blue;
			border:2px solid skyblue;
			color:white;
			padding: 5px;
			font-size: 18px;
			cursor: pointer;
			margin: 16px 0;
			margin-left: 30%;
			margin-top: 5%;
			height:40px;
			border-radius: 15px;

		}
	.reg{
			margin-top: 2%;
			margin-left: 15%;
			padding: 10px;
			font-size: 30px;
			color: white;
			
		}
		.res{
			margin-top: 2%;
			margin-left:0%;
			padding: 10px;
			font-size: 30px;
			color: orange;
			text-decoration: none;
			
		}
		.log{
			float:right;
			color:white;
			margin-right: 45%;
		}
	</style>
</head>
<body>
	<div class="online">
		<h1 class="on"> REAL TIME MEDICATION</h1>
	</div><br>
	<div>
		<h2 class="log">Admin Login</h2>
		</div>

		<div class="bx">
			<form method="post"><div class="icon"><h2><center><img src="pro.png" class="profile"></center></h2></div>
			<input type="text" name="uname" placeholder="username" maxlength="10" class="input" autocomplete="off">
			<input type="password" name="pass" placeholder="password" class="input" autocomplete="off"><br>
			
				<input type="submit" name="login" value="login" class="btn">
				
			</form></div>
	</div>

</body>
</html>
<?php 
      $abc=mysqli_connect('localhost','root','');
      mysqli_select_db($abc,'realtime') or die('plz check database');

if(isset($_POST['login']))
{
	$uname=$_POST['uname'];
	$pass=$_POST['pass'];


	
	$query=mysqli_query($abc,"select *from admin where username='$uname' and password='$pass'");
	$ins=mysqli_fetch_array($query);
	
	if($ins>0)
	{
		$_SESSION['rollno']=$rollno;
		$_SESSION['password']=$pass;
		
	   echo "<script> location.href='data.php'</script>";
		

}
else{
	
	echo "<script> alert('password did not match with username.')</script>";

}
}
     ?>     

  