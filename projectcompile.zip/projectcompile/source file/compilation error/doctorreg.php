<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<title></title>
	<style >
		*{
			margin:0;
			padding: 0;

		}
		body{
			background-color: #add8e6;
		}
		.online{
			
			height: 10%;
			width:100%;
			background-color: skyblue;
			color:white;
			margin-left:0px;
			border:2px solid #cddfff;
		}
		.on{
			margin-left: 35%;
		}
		.login{
			float:right;
			margin-left: 5%;
	        margin-top: -2.5%;
	        margin-right: 10%;
	         
	        text-underline-position:none;
	        background-color: blue;
	        border:2px solid #cddfff;
	        height:30px;
	        width:100px;
	        border-radius: 15px;
	        color:white;

		}
		.box{
			
			height:500px;
			width:1000px;
			background:#cddfff;
			border:2px solid skyblue;
			margin-top: 37%;
            margin-left: 15%;
            border-radius: 20px;
            position: absolute;
            transform: translate(-2%,-98%);

		}
		.left{
			margin-left: 15%;
			height:30px;
			width:30%;
			margin-top: 2%;
			border:2px solid #00bfff;
			border-radius: 15px;

		}
		.dob{
			margin-left: 15%;
			height:30px;
			width:30%;
			margin-top: 2%;
			border:2px solid #00bfff;
			border-radius: 15px;

		}
		.right{
			margin-left: 5%;
			height:30px;
			width:30%;
			margin-top: 2%;
			border:2px solid #00bfff;
			border-radius: 15px;

		}
		.add{
			margin-left: 5%;
			height:30px;
			width:30%;
			margin-top: 2%;
			border:2px solid #00bfff;
			border-radius: 15px;



		}
		.file{
			margin-left: 5%;
			height:30px;
			width:40%;
			margin-top: 2%;
			border:2px solid #00dfff;

			

		}
		.btn{
			width: 40%;
			background:blue;
			border:2px solid skyblue;
			color:white;
			padding: 5px;
			font-size: 18px;
			cursor: pointer;
			margin: 16px 0;
			margin-left: 30%;
			margin-top: 5%;
			height:40px;
		  border-radius: 15px;


		}
		
	</style>
</head>
<body>
	<div class="online">
		<h1 class="on"> <I>REAL TIME MEDICATION</I></h1>
		<a href="doctorlog.php" ><input type="submit" name="login" value="login" class="login"></a>
   
	</div><br>
	<div class="box">
	
	<div>
		<form method="post"  >

			<h1><br>
			<center><b><font color="blue"> Doctor Registration</font></b></center></h1>
			<input type="text" placeholder="name" name="name" class="left" required="required">
			<input type="text" placeholder="email_id " name="email" class="right" required="required" maxlength="50"><br>
			<input type="text"  placeholder="state" name="state" class="left" required="required">
			<input type="text"  placeholder="city" name="city" class="right" required="required"><br>
			<input type="password"  placeholder="password" name="pass" class="left" required="required" >
			<input type="password"  placeholder="confirm password" name="cpass" class="right" required="required"><br>
			<input type="text"  placeholder="department" name="dept" class="dob" required="required">
			<input type="text"  placeholder="address" name="address" class="add" required="required"><br>
			<input type="text" name="hospital" class="dob" placeholder="Hospital_name"  required="required">
			<input type="number" name="mobileno" class="right" placeholder="mobileno."  max length="10" required="required">
			
			
				

				<input type="submit" name="register" value="Register" class="btn" required="required">


		</form>
	</div>
</div>
	
</body>
</html>
<?php SESSION_start();
$ab=mysqli_connect('localhost','root','');
    mysqli_select_db($ab,'realtime') or die('plz check database');
     



if(isset($_POST['register']))

{
	$name=$_POST['name'];
	$dept=$_POST['dept'];
    $pass=$_POST['pass'];
    $cpass=$_POST['cpass'];
    $state=$_POST['state'];
    $city=$_POST['city'];
    $address=$_POST['address'];
	$mobileno=$_POST['mobileno'];
	$email=$_POST['email'];
	$hospital=$_POST['hospital'];
	
	$query="insert into doctorreg(name, email, state, city, password, confirmpassword, Department, address, hospital, mobileno)values('$name','$email','$state','$city','$pass','$cpass','$dept','$address','$hospital','$mobileno')";
	

         

	
	
		if ($cpass==$pass) 
		{
			$in=mysqli_query($ab,$query);
		   	if($in)
		   	{
		   		
		   		echo " <script> alert('successfully registered');</script>";
		   	}
		   else
	      	{
				echo " <script> alert('not registered');</script>";
	      	}

		}
		else
		{
		echo " <script> alert('incorrect password');</script>";
			
		}
}
?>
